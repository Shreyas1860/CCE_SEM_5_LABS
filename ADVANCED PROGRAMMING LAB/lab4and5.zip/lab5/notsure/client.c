#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define PORT 8080
#define SERVER_IP "127.0.0.1"
#define MAX_BUFFER_SIZE 256

int main() {
    int client_socket;
    struct sockaddr_in server_addr;

    // Create socket
    client_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (client_socket < 0) {
        perror("Socket creation failed");
        exit(1);
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    server_addr.sin_addr.s_addr = inet_addr(SERVER_IP);

    // Connect to the server
    if (connect(client_socket, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Connection failed");
        exit(1);
    }

    char message[MAX_BUFFER_SIZE];
    char response[MAX_BUFFER_SIZE];

    // Input source, destination, and number of seats from the user
    int source, destination, seats;
    printf("Enter source (1 or 2), destination (1 or 2), and number of seats to book: ");
    scanf("%d %d %d", &source, &destination, &seats);

    // Send the source, destination, and seats to the server
    sprintf(message, "%d %d %d", source, destination, seats);
    send(client_socket, message, strlen(message), 0);

    // Receive and display the server's response
    recv(client_socket, response, sizeof(response), 0);
    printf("Server Response: %s\n", response);

    close(client_socket);

    return 0;
}
