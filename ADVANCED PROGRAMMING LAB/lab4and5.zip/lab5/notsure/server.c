#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define PORT 8080
#define MAX_BUFFER_SIZE 256

// Database to store seat availability
struct TravelDatabase {
    int source1_destination1;
    int source1_destination2;
    int source2_destination1;
    int source2_destination2;
};

void display_seats(struct TravelDatabase db) {
    printf("\nSeats Available:\n");
    printf("Source 1 -> Destination 1: %d\n", db.source1_destination1);
    printf("Source 1 -> Destination 2: %d\n", db.source1_destination2);
    printf("Source 2 -> Destination 1: %d\n", db.source2_destination1);
    printf("Source 2 -> Destination 2: %d\n", db.source2_destination2);
}

int main() {
    int server_socket, client_socket;
    struct sockaddr_in server_addr, client_addr;
    socklen_t addr_size = sizeof(client_addr);
    char buffer[MAX_BUFFER_SIZE];

    struct TravelDatabase travel_db = {50, 30, 60, 40}; // Initial seat availability

    // Create socket
    server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket < 0) {
        perror("Socket creation failed");
        exit(1);
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    server_addr.sin_addr.s_addr = INADDR_ANY;

    // Bind socket
    if (bind(server_socket, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Binding failed");
        exit(1);
    }

    // Listen for incoming connections
    if (listen(server_socket, 5) == 0) {
        printf("Server is listening...\n");
    } else {
        perror("Listening failed");
        exit(1);
    }

    while (1) {
        // Accept client connection
        client_socket = accept(server_socket, (struct sockaddr *)&client_addr, &addr_size);
        if (client_socket < 0) {
            perror("Acceptance failed");
            exit(1);
        }

        printf("Connected to %s:%d\n", inet_ntoa(client_addr.sin_addr), ntohs(client_addr.sin_port));

        // Display available seats
        display_seats(travel_db);

        // Receive the source-destination and number of seats to book from the client
        recv(client_socket, buffer, sizeof(buffer), 0);
        int source, destination, seats;
        sscanf(buffer, "%d %d %d", &source, &destination, &seats);

        // Check seat availability
        int *ptr;
        if (source == 1 && destination == 1) {
            ptr = &travel_db.source1_destination1;
        } else if (source == 1 && destination == 2) {
            ptr = &travel_db.source1_destination2;
        } else if (source == 2 && destination == 1) {
            ptr = &travel_db.source2_destination1;
        } else if (source == 2 && destination == 2) {
            ptr = &travel_db.source2_destination2;
        } else {
            send(client_socket, "Invalid source or destination", strlen("Invalid source or destination"), 0);
            close(client_socket);
            continue;
        }

        if (*ptr >= seats) {
            // Book the seats
            *ptr -= seats;
            send(client_socket, "Seats booked successfully", strlen("Seats booked successfully"), 0);
        } else {
            // Seats not available
            send(client_socket, "Seats not available", strlen("Seats not available"), 0);
        }

        // Display updated available seats
        display_seats(travel_db);

        // Close the client socket
        close(client_socket);
    }

    close(server_socket);

    return 0;
}
