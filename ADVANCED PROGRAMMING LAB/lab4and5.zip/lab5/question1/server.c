#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/select.h>

#define PORT 8080
#define MAX_BUFFER_SIZE 256
#define MAX_CLIENTS 2

int main() {
    int server_socket, client_sockets[MAX_CLIENTS];
    struct sockaddr_in server_addr, client_addr;
    socklen_t addr_size = sizeof(client_addr);
    fd_set read_fds;
    int max_fd, client_count = 0;
    char buffer[MAX_BUFFER_SIZE];

    // Create socket
    server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket < 0) {
        perror("Socket creation failed");
        exit(1);
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    server_addr.sin_addr.s_addr = INADDR_ANY;

    // Bind socket
    if (bind(server_socket, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Binding failed");
        exit(1);
    }

    // Listen for incoming connections
    if (listen(server_socket, MAX_CLIENTS) == 0) {
        printf("Server is listening...\n");
    } else {
        perror("Listening failed");
        exit(1);
    }

    // Initialize client sockets
    for (int i = 0; i < MAX_CLIENTS; i++) {
        client_sockets[i] = -1;
    }

    int file_fd = open("output.txt", O_APPEND | O_CREAT | O_WRONLY, 0644);

    if (file_fd < 0) {
        perror("File opening failed");
        exit(1);
    }

    while (1) {
        FD_ZERO(&read_fds);
        FD_SET(server_socket, &read_fds);
        max_fd = server_socket;

        // Add active client sockets to the set
        for (int i = 0; i < MAX_CLIENTS; i++) {
            if (client_sockets[i] > 0) {
                FD_SET(client_sockets[i], &read_fds);
                if (client_sockets[i] > max_fd) {
                    max_fd = client_sockets[i];
                }
            }
        }

        // Wait for activity on sockets
        int activity = select(max_fd + 1, &read_fds, NULL, NULL, NULL);

        if ((activity < 0) && (errno != EINTR)) {
            perror("Select error");
        }

        // Check for incoming connections
        if (FD_ISSET(server_socket, &read_fds)) {
            int new_client_socket = accept(server_socket, (struct sockaddr *)&client_addr, &addr_size);

            if (new_client_socket < 0) {
                perror("Acceptance failed");
                exit(1);
            }

            printf("New connection from %s:%d\n", inet_ntoa(client_addr.sin_addr), ntohs(client_addr.sin_port));

            // Find a free slot for the client socket
            for (int i = 0; i < MAX_CLIENTS; i++) {
                if (client_sockets[i] == -1) {
                    client_sockets[i] = new_client_socket;
                    client_count++;

                    // Send a welcome message to the client
                    char welcome_msg[] = "Welcome to the server!\n";
                    send(new_client_socket, welcome_msg, strlen(welcome_msg), 0);

                    // Receive and process client data
                    recv(new_client_socket, buffer, sizeof(buffer), 0);

                    if (strcmp(buffer, "Institute Of") == 0) {
                        strcat(buffer, " ");
                        strcat(buffer, inet_ntoa(client_addr.sin_addr));
                    } else if (strcmp(buffer, "Technology") == 0) {
                        strcat(buffer, " ");
                        strcat(buffer, inet_ntoa(client_addr.sin_addr));
                    }

                    // Write data to file
                    write(file_fd, buffer, strlen(buffer));
                    close(new_client_socket);
                    break;
                }
            }

            // If two clients have connected, display the combined result
            if (client_count == MAX_CLIENTS) {
                lseek(file_fd, 0, SEEK_SET);
                char file_data[MAX_BUFFER_SIZE];
                ssize_t read_bytes = read(file_fd, file_data, sizeof(file_data) - 1);

                if (read_bytes > 0) {
                    file_data[read_bytes] = '\0';
                    printf("Combined result: %s\n", file_data);
                }

                // Send "terminate session" to all clients
                for (int i = 0; i < MAX_CLIENTS; i++) {
                    if (client_sockets[i] > 0) {
                        char terminate_msg[] = "terminate session\n";
                        send(client_sockets[i], terminate_msg, strlen(terminate_msg), 0);
                        close(client_sockets[i]);
                        client_sockets[i] = -1;
                    }
                }

                client_count = 0; // Reset client count
            }
        }
    }

    close(server_socket);
    close(file_fd);

    return 0;
}
