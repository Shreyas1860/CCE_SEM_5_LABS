#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <time.h>

#define PORT 8080
#define MAX_BUFFER_SIZE 256

// Function to check if two strings are anagrams
int are_anagrams(const char *str1, const char *str2) {
    int count1[26] = {0};
    int count2[26] = {0};
    int i;

    // Count character occurrences in the first string
    for (i = 0; str1[i] != '\0'; i++) {
        if (str1[i] != ' ') {
            count1[str1[i] - 'a']++;
        }
    }

    // Count character occurrences in the second string
    for (i = 0; str2[i] != '\0'; i++) {
        if (str2[i] != ' ') {
            count2[str2[i] - 'a']++;
        }
    }

    // Compare character counts
    for (i = 0; i < 26; i++) {
        if (count1[i] != count2[i]) {
            return 0; // Not anagrams
        }
    }

    return 1; // Anagrams
}

int main() {
    int server_socket, client_socket;
    struct sockaddr_in server_addr, client_addr;
    socklen_t addr_size = sizeof(client_addr);
    char buffer[MAX_BUFFER_SIZE];

    // Create socket
    server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket < 0) {
        perror("Socket creation failed");
        exit(1);
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    server_addr.sin_addr.s_addr = INADDR_ANY;

    // Bind socket
    if (bind(server_socket, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Binding failed");
        exit(1);
    }

    // Listen for incoming connections
    if (listen(server_socket, 5) == 0) {
        printf("Server is listening...\n");
    } else {
        perror("Listening failed");
        exit(1);
    }

    while (1) {
        // Accept client connection
        client_socket = accept(server_socket, (struct sockaddr *)&client_addr, &addr_size);
        if (client_socket < 0) {
            perror("Acceptance failed");
            exit(1);
        }

        // Get current date and time
        time_t current_time;
        struct tm *time_info;
        char time_str[MAX_BUFFER_SIZE];

        time(&current_time);
        time_info = localtime(&current_time);
        strftime(time_str, sizeof(time_str), "%Y-%m-%d %H:%M:%S", time_info);

        printf("Connected to %s:%d at %s\n", inet_ntoa(client_addr.sin_addr), ntohs(client_addr.sin_port), time_str);

        // Receive two strings from the client
        recv(client_socket, buffer, sizeof(buffer), 0);
        char str1[MAX_BUFFER_SIZE], str2[MAX_BUFFER_SIZE];
        sscanf(buffer, "%s %s", str1, str2);

        // Check if the strings are anagrams
        int result = are_anagrams(str1, str2);

        // Send the result to the client
        if (result) {
            send(client_socket, "Anagrams", strlen("Anagrams"), 0);
        } else {
            send(client_socket, "Not Anagrams", strlen("Not Anagrams"), 0);
        }

        // Close the client socket
        close(client_socket);
    }

    close(server_socket);

    return 0;
}
