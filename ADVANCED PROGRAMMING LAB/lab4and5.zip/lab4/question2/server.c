#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>

#define PORT 8080
#define DATABASE_FILE "database.txt"
#define MAX_BUFFER_SIZE 256

// Structure to store DNS records (for simplicity)
struct DNSRecord {
    char hostname[100];
    char ip_address[20];
};

// Function to handle DNS queries
void handle_dns_query(int client_socket) {
    FILE *database = fopen(DATABASE_FILE, "r");
    if (database == NULL) {
        perror("Database file opening failed");
        exit(1);
    }

    char hostname[MAX_BUFFER_SIZE];
    char response[MAX_BUFFER_SIZE];
    int found = 0;

    // Receive hostname from client
    recv(client_socket, hostname, sizeof(hostname), 0);

    // Search for the hostname in the database
    struct DNSRecord record;
    while (fread(&record, sizeof(struct DNSRecord), 1, database)) {
        if (strcmp(record.hostname, hostname) == 0) {
            strcpy(response, record.ip_address);
            found = 1;
            break;
        }
    }

    if (!found) {
        strcpy(response, "Not found");
    }

    // Send response to the client
    send(client_socket, response, strlen(response), 0);

    fclose(database);
    close(client_socket);
}

int main() {
    int server_socket, client_socket;
    struct sockaddr_in server_addr, client_addr;

    // Create socket
    server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket < 0) {
        perror("Socket creation failed");
        exit(1);
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    server_addr.sin_addr.s_addr = INADDR_ANY;

    // Bind socket
    if (bind(server_socket, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Binding failed");
        exit(1);
    }

    // Listen for incoming connections
    if (listen(server_socket, 5) == 0) {
        printf("DNS Server is listening...\n");
    } else {
        perror("Listening failed");
        exit(1);
    }

    socklen_t addr_size = sizeof(client_addr);

    while (1) {
        // Accept client connection
        client_socket = accept(server_socket, (struct sockaddr *)&client_addr, &addr_size);
        if (client_socket < 0) {
            perror("Acceptance failed");
            exit(1);
        }

        // Handle DNS query in a child process
        if (fork() == 0) {
            handle_dns_query(client_socket);
            exit(0);
        }

        close(client_socket);
    }

    close(server_socket);

    return 0;
}
