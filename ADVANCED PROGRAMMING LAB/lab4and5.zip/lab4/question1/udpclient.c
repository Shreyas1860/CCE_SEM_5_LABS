#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8080
#define SERVER_IP "127.0.0.1"

int main() {
    int client_socket;
    struct sockaddr_in server_addr;

    // Create socket
    client_socket = socket(AF_INET, SOCK_DGRAM, 0);
    if (client_socket < 0) {
        perror("Socket creation failed");
        exit(1);
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    server_addr.sin_addr.s_addr = inet_addr(SERVER_IP);

    // Menu
    printf("Choose an option:\n");
    printf("1. Registration Number\n");
    printf("2. Name of the Student\n");
    printf("3. Subject Code\n");
    char option;
    scanf(" %c", &option);

    // Send option to server
    sendto(client_socket, &option, sizeof(option), 0, (struct sockaddr*)&server_addr, sizeof(server_addr));

    if (option == '3') {
        char subject_code[10];
        printf("Enter Subject Code: ");
        scanf("%s", subject_code);

        // Send subject code to server
        sendto(client_socket, subject_code, sizeof(subject_code), 0, (struct sockaddr*)&server_addr, sizeof(server_addr));
    }

    char response[256];
    socklen_t addr_size = sizeof(server_addr);

    // Receive and display server's response
    recvfrom(client_socket, response, sizeof(response), 0, (struct sockaddr*)&server_addr, &addr_size);
    printf("Server Response: %s\n", response);

    close(client_socket);

    return 0;
}
