#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8080
#define MAX_BUFFER_SIZE 256

void handle_registration(int client_socket, struct sockaddr_in client_addr) {
    // Simulate database lookup for registration number
    char registration_data[MAX_BUFFER_SIZE] = "John Doe\n123 Main St, City\nPID: ";
    char pid_str[10];
    sprintf(pid_str, "%d", getpid());
    strcat(registration_data, pid_str);
    
    sendto(client_socket, registration_data, strlen(registration_data), 0, (struct sockaddr*)&client_addr, sizeof(client_addr));
}

void handle_name(int client_socket, struct sockaddr_in client_addr) {
    // Simulate database lookup for student name
    char student_data[MAX_BUFFER_SIZE] = "Department: Computer Science\nSemester: 4\nSection: A\nCourses Registered: C++, Networking\nPID: ";
    char pid_str[10];
    sprintf(pid_str, "%d", getpid());
    strcat(student_data, pid_str);
    
    sendto(client_socket, student_data, strlen(student_data), 0, (struct sockaddr*)&client_addr, sizeof(client_addr));
}

void handle_subject(int client_socket, struct sockaddr_in client_addr, char* subject_code) {
    // Simulate database lookup for subject marks
    char subject_data[MAX_BUFFER_SIZE] = "Marks for Subject Code: ";
    
    // Simulate marks retrieval based on subject code
    strcat(subject_data, subject_code);
    strcat(subject_data, ": 90\nPID: ");
    
    char pid_str[10];
    sprintf(pid_str, "%d", getpid());
    strcat(subject_data, pid_str);
    
    sendto(client_socket, subject_data, strlen(subject_data), 0, (struct sockaddr*)&client_addr, sizeof(client_addr));
}

int main() {
    int server_socket;
    struct sockaddr_in server_addr, client_addr;

    // Create socket
    server_socket = socket(AF_INET, SOCK_DGRAM, 0);
    if (server_socket < 0) {
        perror("Socket creation failed");
        exit(1);
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    server_addr.sin_addr.s_addr = INADDR_ANY;

    // Bind socket
    if (bind(server_socket, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        perror("Binding failed");
        exit(1);
    }

    printf("UDP Server is running...\n");

    socklen_t addr_size = sizeof(client_addr);
    char option;
    char subject_code[10];

    while (1) {
        // Receive option from client
        recvfrom(server_socket, &option, sizeof(option), 0, (struct sockaddr*)&client_addr, &addr_size);

        if (option == '1') {
            handle_registration(server_socket, client_addr);
        } else if (option == '2') {
            handle_name(server_socket, client_addr);
        } else if (option == '3') {
            // Receive subject code from client
            recvfrom(server_socket, subject_code, sizeof(subject_code), 0, (struct sockaddr*)&client_addr, &addr_size);
            handle_subject(server_socket, client_addr, subject_code);
        }
    }

    close(server_socket);

    return 0;
}
