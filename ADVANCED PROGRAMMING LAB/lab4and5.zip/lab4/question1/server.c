#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8080

void handle_registration(int client_socket) {
    // Simulate database lookup for registration number
    char registration_data[256] = "John Doe\n123 Main St, City\nPID: ";
    char pid_str[10];
    sprintf(pid_str, "%d", getpid());
    strcat(registration_data, pid_str);
    
    send(client_socket, registration_data, strlen(registration_data), 0);
}

void handle_name(int client_socket) {
    // Simulate database lookup for student name
    char student_data[256] = "Department: Computer Science\nSemester: 4\nSection: A\nCourses Registered: C++, Networking\nPID: ";
    char pid_str[10];
    sprintf(pid_str, "%d", getpid());
    strcat(student_data, pid_str);
    
    send(client_socket, student_data, strlen(student_data), 0);
}

void handle_subject(int client_socket) {
    // Simulate database lookup for subject marks
    char subject_data[256] = "Marks for Subject Code: ";
    
    // Receive subject code from client
    char subject_code[10];
    recv(client_socket, subject_code, sizeof(subject_code), 0);
    
    // Simulate marks retrieval based on subject code
    strcat(subject_data, subject_code);
    strcat(subject_data, ": 90\nPID: ");
    
    char pid_str[10];
    sprintf(pid_str, "%d", getpid());
    strcat(subject_data, pid_str);
    
    send(client_socket, subject_data, strlen(subject_data), 0);
}

int main() {
    int server_socket, client_socket;
    struct sockaddr_in server_addr, client_addr;
    socklen_t addr_size;

    // Create socket
    server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket < 0) {
        perror("Socket creation failed");
        exit(1);
    }

    // Bind socket
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    server_addr.sin_addr.s_addr = INADDR_ANY;
    if (bind(server_socket, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        perror("Binding failed");
        exit(1);
    }

    // Listen for incoming connections
    if (listen(server_socket, 5) == 0) {
        printf("Listening...\n");
    } else {
        perror("Listening failed");
        exit(1);
    }

    addr_size = sizeof(client_addr);
    client_socket = accept(server_socket, (struct sockaddr*)&client_addr, &addr_size);

    // Receive option from client
    char option;
    recv(client_socket, &option, sizeof(option), 0);

    // Fork child processes to handle different tasks
    if (fork() == 0) {
        if (option == '1') {
            handle_registration(client_socket);
        }
        exit(0);
    } else if (fork() == 0) {
        if (option == '2') {
            handle_name(client_socket);
        }
        exit(0);
    } else if (fork() == 0) {
        if (option == '3') {
            handle_subject(client_socket);
        }
        exit(0);
    }

    // Wait for all child processes to finish
    for (int i = 0; i < 3; i++) {
        wait(NULL);
    }

    close(client_socket);
    close(server_socket);

    return 0;
}
